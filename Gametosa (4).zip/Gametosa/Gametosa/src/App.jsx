// src/App.jsx
import React from "react";

function App() {
  return (
    <h1 className="text-3xl font-bold text-center mt-10">
      Welcome to Gametosa 🎮
    </h1>
  );
}

export default App;
