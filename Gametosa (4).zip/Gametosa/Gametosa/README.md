Gametosa - Gaming E-commerce Frontend

This is the frontend of the Gametosa Gaming E-commerce Website, built using React, Vite, and Tailwind CSS.


Folder Structure :

Gametosa/
│-- node_modules/            # Installed dependencies
│-- public/                  # Static assets
│
│-- src/
│   │-- components/          # Reusable components
│   │   │-- navigation/      # Navigation bar and related components
│   │   └── AppRoutes.jsx    # App routing configuration
│   │
│   │-- screens/             # Application screens (pages)
│   │   │-- Cart/            # Cart screen
│   │   │-- Category/        # Category listing screen
│   │   │-- Checkout/        # Checkout process
│   │   │-- Home/            # Homepage
│   │   │-- Landing Page/    # Landing page
│   │   │-- Login/           # Login screen
│   │   │-- Notifications/   # Notifications page
│   │   │-- Orders/          # Orders history
│   │   │-- Profile/         # User profile
│   │   │-- Rewards/         # Rewards system
│   │   └── Wishlist/        # Wishlist page
│   │
│   │-- App.jsx              # Root component
│   │-- main.jsx             # Application entry point
│
│-- eslint.config.js         # ESLint configuration
│-- index.html               # Base HTML file
│-- package.json             # Project dependencies and scripts
│-- vite.config.js           # Vite configuration
│-- tailwind.config.js       # Tailwind CSS configuration
│-- README.md                # Documentation
